using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ContactsTableCosmosWebApp.Models.Abstract;
using ContactsTableCosmosWebApp.Models.Entities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

namespace ContactsTableCosmosWebApp.Models.Concrete
{
  public class TableContactRepository : IContactRepository
  {
    private readonly ILogger<TableContactRepository> _logger;
    private readonly CloudStorageAccount _cloudStorageAccount;
    private readonly CloudTableClient _cloudTableClient;
    private readonly CloudTable _cloudTable;

    public TableContactRepository(IOptions<StorageUtility> storageUtility, ILogger<TableContactRepository> logger)
    {
      _logger = logger;
      _cloudStorageAccount = storageUtility.Value.StorageAccount;
      _cloudTableClient = _cloudStorageAccount.CreateCloudTableClient();
      _cloudTable = _cloudTableClient.GetTableReference("Contacts");
      _cloudTable.CreateIfNotExistsAsync().GetAwaiter().GetResult();
    }

    private ContactTable SetContactTableObject(Contact contact)
    {
      contact.Id = Guid.NewGuid().ToString();
      ContactTable contactTable = new ContactTable
      {
        Id = contact.Id,
        PartitionKey = contact.ContactName,
        RowKey = contact.Phone,
        ContactType = contact.ContactType,
        Email = contact.Email
      };
      return contactTable;
    }

    private Contact SetContactObject(ContactTable contactTable)
    {
      Contact contact = new Contact
      {
        Id = contactTable.Id,
        ContactName = contactTable.PartitionKey,
        Phone = contactTable.RowKey,
        ContactType = contactTable.ContactType,
        Email = contactTable.Email
      };
      return contact;
    }

    private List<Contact> SetContactsList(List<ContactTable> contactTableList)
    {
      List<Contact> contactsList = new List<Contact>();
      foreach (var item in contactTableList)
      {
        contactsList.Add(SetContactObject(item));
      }
      return contactsList;
    }
    public async Task<Contact> CreateAsync(Contact contact)
    {
      throw new NotImplementedException();
    }

    public async Task DeleteAsync(string id, string contactName, string phone)
    {
      throw new NotImplementedException();
    }

    public async Task<Contact> FindContactAsync(string id)
    {
      throw new NotImplementedException();
    }

    public async Task<List<Contact>> FindContactByPhoneAsync(string phone)
    {
      throw new NotImplementedException();
    }

    public async Task<List<Contact>> FindContactCPAsync(string contactName, string phone)
    {
      var partitionKey = contactName;
      var rowKey = phone;
      TableOperation retrieveOperation = TableOperation.Retrieve<ContactTable>(partitionKey, rowKey);
      TableResult tableResult = await _cloudTable.ExecuteAsync(retrieveOperation);
      var result = tableResult.Result as ContactTable;
      var contact = SetContactObject(result);
      return new List<Contact> { contact };
    }

    public async Task<List<Contact>> FindContactsByContactNameAsync(string contactName)
    {
      var partitionKey = contactName;
      TableQuery<ContactTable> query = new TableQuery<ContactTable>()
          .Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, partitionKey));
      TableContinuationToken tcToken = null;
      var contactTableResult = await _cloudTable.ExecuteQuerySegmentedAsync(query, tcToken);
      return SetContactsList(contactTableResult.Results);
    }

    public async Task<List<Contact>> GetAllContactsAsync()
    {
      throw new NotImplementedException();
    }

    public async Task<Contact> UpdateAsync(Contact contact)
    {
      throw new NotImplementedException();
    }

    public void ClearCache()
    {
      throw new NotImplementedException();

      // Implement if cache is used.
    }
  }
}
