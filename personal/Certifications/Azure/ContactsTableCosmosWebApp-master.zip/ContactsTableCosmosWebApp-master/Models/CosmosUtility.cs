namespace ContactsTableCosmosWebApp.Models
{
  public class CosmosUtility
  {
    public string CosmosEndpoint { get; set; }
    public string CosmosKey { get; set; }
  }
}