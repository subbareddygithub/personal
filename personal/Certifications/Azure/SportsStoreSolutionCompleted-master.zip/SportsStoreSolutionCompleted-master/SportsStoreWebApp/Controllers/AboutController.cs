﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Configuration;

namespace SportsStoreWebApp.Controllers
{
  public class AboutController : Controller
  {
    private readonly IConfiguration _configuration;

    public AboutController(IConfiguration configuration)
    {
      _configuration = configuration;
    }
    public async Task<IActionResult> Index()
    {
      var keyVaultName = _configuration["SSKeyVault"];

      if (!string.IsNullOrEmpty(keyVaultName))
      {
        AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
        KeyVaultClient keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));

        var secrets = await keyVaultClient.GetSecretsAsync(keyVaultName);

        Dictionary<string, string> secretVaultList = new Dictionary<string, string>();
        foreach (var item in secrets)
        {
          var secret = await keyVaultClient.GetSecretAsync($"{item.Id}");
          secretVaultList.Add(item.Id, secret.Value);
        }
        return View(secretVaultList);
      }
      return View(new Dictionary<string, string>() { ["KeyVault"] = "Empty" });
    }
    public IActionResult Throw()
    {
      throw new EntryPointNotFoundException("This is a user thrown exception");
    }
  }
}

