using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Options;

namespace ContactBookLibrary
{
  public class CosmosContext
  {
    private readonly string _cosmosKey;
    private readonly string _cosmosEndpoint;
    private readonly string _databaseId;
    private readonly string _containerId;
    private Database _database;
    private Container _container;
    private CosmosClient _cosmosClient;

    public CosmosContext(IOptions<CosmosUtility> cosmosUtility)
    {
      _cosmosKey = cosmosUtility.Value.CosmosKey;
      _cosmosEndpoint = cosmosUtility.Value.CosmosEndpoint;
      _databaseId = cosmosUtility.Value.DatabaseId;
      _containerId = cosmosUtility.Value.ContainerId;

      _cosmosClient = new CosmosClient(_cosmosEndpoint, _cosmosKey);
    }

    public bool CreateDatabaseIfNotExists()
    {
      _cosmosClient.CreateDatabaseIfNotExistsAsync(_databaseId).GetAwaiter().GetResult();
      _database = _cosmosClient.GetDatabase(_databaseId);
      return true;
    }
    public bool CreateContainerIfNotExists()
    {
      _database.CreateContainerIfNotExistsAsync(_containerId, "/contactName").GetAwaiter().GetResult();
      _container = _database.GetContainer(_containerId);
      return true;
    }

  }
}