# DotNetCore 5.0  ClassLibrary for CosmosDb

#### Create ClassLibrary Project

- dotnet new classlib --name ContactBookLibrary -f net5.0

#### Packages for the Project

- dotnet add package Newtonsoft.Json -v 13.0.1
- dotnet add package Microsoft.Extensions.Options -v 5.0.0
- dotnet add package Microsoft.Extensions.Configuration -v 5.0.0
- dotnet add package Microsoft.Azure.Cosmos -v 3.25.0
