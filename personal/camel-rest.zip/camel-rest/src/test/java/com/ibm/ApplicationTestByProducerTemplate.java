package com.ibm;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.ServiceStatus;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

@SpringBootTest
@CamelSpringBootTest
public class ApplicationTestByProducerTemplate {

	@Autowired
	private CamelContext camelContext;

	@Autowired
	private ProducerTemplate producerTemplate;

	MockEndpoint mockHello;

	Integer port=8080;

	// Uncomment this working code to ensue all is working
	@Test
	public void test() throws Exception {
		mockHello = camelContext.getEndpoint("mock:stream:out", MockEndpoint.class);

		AdviceWith.adviceWith(camelContext, "hello",
				// intercepting an exchange on route
				r -> {
					// replacing consumer with direct component
					r.replaceFromWith("direct:start");
					// mocking producer
					r.mockEndpoints("stream*");
				}
		);

		// setting expectations
		mockHello.expectedMessageCount(1);
		mockHello.expectedBodiesReceived("Hello World");

		// invoking consumer
		producerTemplate.sendBody("direct:start", null);

		// asserting mock is satisfied
		mockHello.assertIsSatisfied();
	}


	@Test
	public void testUserGet() throws Exception {
		MockEndpoint mockEndpointUser = camelContext.getEndpoint("mock:users", MockEndpoint.class);
		
		AdviceWith.adviceWith(camelContext, "get-user-by-id",
			// intercepting an exchange on route
			r -> {
				// replacing consumer with direct component
				r.replaceFromWith("direct:rest-with-get");
				// mocking producer
				r.mockEndpoints("users*");
			}
		);

		User mockUser = new User(3, "Sonny Rollins");

		mockEndpointUser.expectedBodiesReceived(mockUser);
		mockEndpointUser.expectedMessageCount(0);

		//Send a message to each put endpoint
		ExchangeBuilder builder = ExchangeBuilder.anExchange(camelContext)
			.withHeader(Exchange.HTTP_METHOD, HttpMethod.GET)
			.withHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON)
			.withHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

		// Exchange outExchangeUser = builder.withHeader(Exchange.HTTP_RESPONSE_CODE, 204).withBody("User successfully updated").build();
		Exchange outExchange = builder.withHeader("id", 3).build();
		Exchange responseExchange = producerTemplate.send("direct:rest-with-get", outExchange);
		
		assertNotNull(responseExchange.getIn().getBody());
		assertEquals(mockUser.toString(), responseExchange.getIn().getBody().toString());
		assertEquals(200, responseExchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE));		
		mockEndpointUser.assertIsSatisfied();
	}

	@Test
	public void testUserGetNotFound() throws Exception {
		MockEndpoint mockEndpointUser = camelContext.getEndpoint("mock:users", MockEndpoint.class);
		
		AdviceWith.adviceWith(camelContext, "get-user-by-id",
			// intercepting an exchange on route
			r -> {
				// replacing consumer with direct component
				r.replaceFromWith("direct:rest-with-get");
				// mocking producer
				r.mockEndpoints("users*");
			}
		);

		// mockEndpointUser.expectedBodiesReceived(mockUser);
		mockEndpointUser.expectedMessageCount(0);

		//Send a message to each put endpoint
		ExchangeBuilder builder = ExchangeBuilder.anExchange(camelContext)
			.withHeader(Exchange.HTTP_METHOD, HttpMethod.GET)
			.withHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON)
			.withHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

		// Exchange outExchangeUser = builder.withHeader(Exchange.HTTP_RESPONSE_CODE, 204).withBody("User successfully updated").build();
		Exchange outExchange = builder.withHeader("id", 101).build();
		Exchange responseExchange = producerTemplate.send("direct:rest-with-get", outExchange);
		
		assertNull(responseExchange.getIn().getBody());
		assertEquals(404, responseExchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE));		
		mockEndpointUser.assertIsSatisfied();
	}

	@Test
	public void testUserGetAll() throws Exception {
		MockEndpoint mockEndpointUser = camelContext.getEndpoint("mock:users", MockEndpoint.class);
		
		AdviceWith.adviceWith(camelContext, "get-users",
			// intercepting an exchange on route
			r -> {
				// replacing consumer with direct component
				r.replaceFromWith("direct:rest-with-get-all");
				// mocking producer
				r.mockEndpoints("users*");
			}
		);

		// mockEndpointUser.expectedBodiesReceived(mockUser);
		mockEndpointUser.expectedMessageCount(0);

		//Send a message to each put endpoint
		ExchangeBuilder builder = ExchangeBuilder.anExchange(camelContext)
			.withHeader(Exchange.HTTP_METHOD, HttpMethod.GET)
			.withHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON)
			.withHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

		// Exchange outExchangeUser = builder.withHeader(Exchange.HTTP_RESPONSE_CODE, 204).withBody("User successfully updated").build();
		Exchange outExchange = builder.withHeader("id", "").build();
		Exchange responseExchange = producerTemplate.send("direct:rest-with-get-all", outExchange);
		
		assertNotNull(responseExchange.getIn().getBody());
		// assertEquals(3,  resp.size());
		//assertEquals(200, responseExchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));		
		mockEndpointUser.assertIsSatisfied();
	}

	@Test
	public void testUserPut() throws Exception {
		MockEndpoint mockEndpointUser = camelContext.getEndpoint("mock:users", MockEndpoint.class);
		
		AdviceWith.adviceWith(camelContext, "put-user-by-id",
			// intercepting an exchange on route
			r -> {
				// replacing consumer with direct component
				r.replaceFromWith("direct:rest-with-put");
				// mocking producer
				r.mockEndpoints("users*");
			}
		);

		final String responseBody = "User successfully updated";

		mockEndpointUser.expectedBodiesReceived(responseBody);
		mockEndpointUser.expectedMessageCount(0);

		//Send a message to each put endpoint
		ExchangeBuilder builder = ExchangeBuilder.anExchange(camelContext)
			.withHeader(Exchange.HTTP_METHOD, HttpMethod.PUT)
			.withHeader(Exchange.CONTENT_TYPE, MediaType.APPLICATION_JSON)
			.withHeader(Exchange.ACCEPT_CONTENT_TYPE, MediaType.APPLICATION_JSON);

		// Exchange outExchangeUser = builder.withHeader(Exchange.HTTP_RESPONSE_CODE, 204).withBody("User successfully updated").build();
		Exchange outExchangeUser = builder.withHeader("id", 3)
										  .withBody("{\"id\": 3, \"name\": \"Indu\"}").build();
		Exchange responseExchange = producerTemplate.send("direct:rest-with-put", outExchangeUser);
		
		assertEquals(responseBody, responseExchange.getIn().getBody().toString());
		assertEquals(204, responseExchange.getIn().getHeader("CamelHttpResponseCode"));		
		mockEndpointUser.assertIsSatisfied();
	}

	@Test
	public void testCamelStarts() {
		assertEquals(ServiceStatus.Started, camelContext.getStatus());
		// assertNotNull(camelContext.getRoutes()).hasSizeGreaterThan(0);
	}
}
